/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package regularpolygon;

import java.text.DecimalFormat;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.inject.Named;

/**
 *
 * @author S524965
 */
@ManagedBean
@Named(value = "ambati")
@RequestScoped
public class Ambati {
    private Integer nsides;
    private Integer radius; 
    /**
     * Creates a new instance of Ambati
     */
    public Ambati() {
    }

    public Integer getNsides() {
        return nsides;
    }

    public void setNsides(Integer nsides) {
        this.nsides = nsides;
    }

    public Integer getRadius() {
        return radius;
    }

    public void setRadius(Integer radius) {
        this.radius = radius;
    }

    
    
    public String length(){
        
       return String.format("%.2f",2*getRadius()*Math.sin(Math.PI/getNsides()));
    }
    
    public String area(){
    
        return String.format("%.2f",(getRadius()*getRadius()*getNsides()*(Math.sin(2*Math.PI/getNsides())))/2);
    }
    
    public String perimeter(){
        return String.format("%.2f",(2*getRadius()*Math.sin(Math.PI/getNsides()))*getNsides());
    }
    
    
}
