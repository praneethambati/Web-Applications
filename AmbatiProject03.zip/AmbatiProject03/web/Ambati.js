/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


function calculatePrice() {
   // Price List
   SMALL = 6.00;
   MEDIUM = 9.00;
   LARGE = 11.00;
   CHOCOLATE = 1.00;
   MINTCHOCOLATE = 1.25;
  STRAWBERRY = 1.50;
   VANILLA = 1.50;
   SALTED=0.50;
   SUGARFREE=0.70;

   var price = 0.00;
   var allDataEntered = true;

   if (document.getElementById("flavor").value == "chocolate") {
      price += CHOCOLATE;
   } 
   else if (document.getElementById("flavor").value == "mint") {
      price += MINTCHOCOLATE;
   }
   else if (document.getElementById("flavor").value == "strawberry") {
      price += STRAWBERRY;
    } 
    else if (document.getElementById("flavor").value == "vanilla") {
      price += VANILLA;
  }
      else {
      allDataEntered = false;
      alert("You must select the flavor you want.");
   }

   if (document.getElementById("small").checked) {
      price += SMALL;
   } else if (document.getElementById("medium").checked) {
      price += MEDIUM;
   } else if (document.getElementById("large").checked) {
      price += LARGE;
   } else {
      allDataEntered = false;
      alert("You must select the size of ice cream you want.");
   }

   if (document.getElementById("saltedcaramel").checked) {
      price += SALTED;
   }

   if (document.getElementById("sugarfree").checked) {
      price += SUGARFREE;
   }

    var quantity=document.getElementById("quantity").value;
  if(quantity>=1&&quantity<=10&& quantity.indexOf('.')<0){
    price *=parseInt(quantity);
  
   if(allDataEntered) {
      document.getElementById("price").innerHTML = "<h3>The total cost is $" + price.toFixed(2)+"</h3>";
      document.getElementById("time").innerHTML= "<h3>Your order will be delivered in about "+(Math.round(Math.random() * (45 - 25)) + 25)+" minutes</h3>";
   }
  }
  else if(quantity<=0)
  {
      window.alert("Quantity must be atleast 1");
  }
  else if(quantity>10){
      window.alert("Quantity can be atmost 10");
  }
  else if(quantity.indexOf('.')>=1){
      window.alert("Quantity should be only integers between 1 to 10");
  }
  else {
      window.alert("Enter Quantity");   
  }
}

window.onload = function() {
   document.getElementById("order").onclick = calculatePrice;
};

