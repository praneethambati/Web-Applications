
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPathExpressionException;
import org.xml.sax.SAXException;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author s524965
 */
public class SongInformation {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws ParserConfigurationException, SAXException, IOException, XPathExpressionException {
        SongParser songParser=new SongParser();
       List<Song> song = songParser.getSongFromXMLFile("songs.xml");
       System.out.println("Song Information\n"); 
       
         System.out.printf("%-25s %-22s %3s   %7s\n","Title","Singer","Length","Average rating");

      for(Song songs:song){
          System.out.println(songs);
      }
       
      System.out.println("\nAll Songs More Than Six Minutes Long");
      for(int i=0;i<song.size();i++){
          if(song.get(i).getLength()>=6)
          {
              System.out.println(song.get(i).getTitle());
          }
      }
      
       String lowRate=song.get(0).getTitle();
        double minRate=song.get(0).getAverageRating();
        for(int i=1;i<song.size();i++){
            if(minRate>song.get(i).getAverageRating()){
                minRate=song.get(i).getAverageRating();
                lowRate=song.get(i).getTitle();
            }    
        }
         
        double lowAvg = Integer.MAX_VALUE;
        String sTitle = "";
        for(Song s : song){
            if(s.getAverageRating() < lowAvg){
                lowAvg = s.getAverageRating();
                sTitle = s.getTitle();
            }
        }
        System.out.println("\n" + "The song with the lowest average rating is " +sTitle);
        
        int len = Integer.MIN_VALUE;
        String sTitle1 = "";
        for(Song s : song){
            if(s.getLength() > len){
                len = s.getLength();
                sTitle1 = s.getTitle();
            }
        }
        System.out.println("The longest song is " +sTitle1);
        
        int c = 0;
        double totAvgLen = 0;
        for(Song s : song){
            totAvgLen += s.getLength();
            c++;
        }
        System.out.println("The average length of the song is " + (totAvgLen/c) + " minutes");
    }
    
}
