
import java.util.ArrayList;
import java.util.List;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author s524965
 */
public class Song {
    private String title;
    private String singer;
    private int length;
    List<Integer> ratings;
    
    public Song(String title,String singer,int length,List<Integer> ratings){
        this.title= title;
        this.singer=singer;
        this.length=length;
        this.ratings=ratings;
    }

   
    
    public String getTitle(){
    return this.title;
    }

    public int getLength() {
        return length;
    }

    public List<Integer> getRatings() {
        return ratings;
    }

    public String getSinger() {
        return singer;
    }
    
   public double getAverageRating(){
        double avg = 0.0;
        for(Integer rate : ratings){
            avg += rate;
        }
        return (avg/ratings.size());
    }

   
    @Override
    public String toString(){
        return String.format("%-25s %-25s %3d %5.1f", this.title,this.singer,this.length,this.getAverageRating());
    }
    
}
