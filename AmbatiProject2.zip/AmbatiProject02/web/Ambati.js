/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
    function calc()
            {
           var sides= document.getElementById('sides').value;
           var radius= document.getElementById('radius').value;
           
           if(sides>2)
           {
         
           
           var length=2*radius*Math.sin(Math.PI/sides);
           var perimeter=length*sides;
           var area=((radius*radius*sides*(Math.sin(2*Math.PI/sides)))/2);
           
           document.getElementById("length").value=length.toFixed(2);
           document.getElementById("perimeter").value=perimeter.toFixed(2);
           document.getElementById("area").value=area.toFixed(2);
       }
       else
       {
           window.alert("Minimum sides value should be above 2");
       }
        
            
            
          
            }
            window.onload = function() {
    
                     document.getElementById("sides").focus();
            };
     