/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

$(document).ready(function(){
    $("#order").click(function(){
        calculatePrice();
    });
    });

var calculatePrice=function() {
   // Price List
   SMALL = 6.00;
   MEDIUM = 9.00;
   LARGE = 11.00;
   CHOCOLATE = 1.00;
   MINTCHOCOLATE = 1.25;
  STRAWBERRY = 1.50;
   VANILLA = 1.50;
   SALTED=0.50;
   SUGARFREE=0.70;

   var price = 0.00;
   var allDataEntered = true;

   if ($("#flavor :selected").val() == "chocolate") {
      price += CHOCOLATE;
      
   } 
   
   else if ($("#flavor :selected").val() == "mint") {
      price += MINTCHOCOLATE;
    
   }
   else if ($("#flavor :selected").val() == "strawberry") {
      price += STRAWBERRY;
     
    } 
    else if ($("#flavor :selected").val() == "vanilla") {
      price += VANILLA;
     
  }
      else {
      allDataEntered = false;
      $("body").css("background-color","#ccffff");
        $("#ice").hide();
      alert("You must select the flavor you want.");
   }
   
   if ($('input:radio[name=size]:checked').val()=="small") {
      price += SMALL;
   } else if ($('input:radio[name=size]:checked').val()=="medium") {
      price += MEDIUM;
   } else if ($('input:radio[name=size]:checked').val()=="large") {
      price += LARGE;
   } else {
      allDataEntered = false;
      $("body").css("background-color","#ccffff");
        $("#ice").hide();
      alert("You must select the size of ice cream you want.");
   }

   
   if ($('input:checkbox[name=extra]:checked').val()=="salted") {
      price += SALTED;
   }

    if ($('input:checkbox[name=extraa]:checked').val()=="sugar") {
      price += SUGARFREE;
   }
   

    var quantity=$("#quantity").val();
    
  if(quantity>=1&&quantity<=10&& quantity.indexOf('.')<0){
    price *=parseInt(quantity);
  
   if(allDataEntered) {
       
        $("#ice").slideDown(5000);
       if ($("#flavor :selected").val() == "chocolate") {
      
      $("body").css("background-color","yellow");
   } 
   
   else if ($("#flavor :selected").val() == "mint") {
     
     $("body").css("background-color","sienna");
   }
   else if ($("#flavor :selected").val() == "strawberry") {
     
      $("body").css("background-color","pink    ");
    } 
    else if ($("#flavor :selected").val() == "vanilla") {
      
      $("body").css("background-color","cornsilk");
  }
  
  
     $("#price").html("<h3>The total cost is $" + price.toFixed(2)+"</h3>");
      $("#time").html("<h3>Your order will be delivered in about "+(Math.round(Math.random() * (45 - 25)) + 25)+" minutes</h3>");
   $("#ice").show("slide", { direction: "right" }, 2000);
         }
  }
  else if(quantity<=0)
  {
       $("body").css("background-color","#ccffff");
        $("#ice").hide();
      window.alert("Quantity must be atleast 1");
  
  }
  else if(quantity>10){
       $("#ice").hide();
       $("body").css("background-color","#ccffff");
      window.alert("Quantity can be atmost 10");
       
  }
  else if(quantity.indexOf('.')>=1){
      $("#ice").hide();
       $("body").css("background-color","#ccffff");
      window.alert("Quantity should be only integers between 1 to 10");
        
  }
  else {
      $("#ice").hide();
       $("body").css("background-color","#ccffff");
      window.alert("Enter Quantity");  
        $("#ice").hide();
  }
  
 
};
