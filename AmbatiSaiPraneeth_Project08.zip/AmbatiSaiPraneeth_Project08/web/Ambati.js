/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


window.onload = function() {
    document.getElementById("order").onclick = getOrder;
    
}

function getOrder() {
     document.getElementById("message").innerHTML ="";
     var size="";
     var toppings1="";
     var toppings2="";
     var allDataEntered=true;
    //clearCourses();
    var flavor= document.getElementById("flavor").value;
    if(flavor==="none"){
        allDataEntered=false;
        alert("Please select a flavor");
    }
    
   if (document.getElementById('small').checked) {
   size = document.getElementById('small').value;
    }
    else if (document.getElementById('medium').checked) {
     size = document.getElementById('medium').value;
    }
    else if (document.getElementById('large').checked) {
      size = document.getElementById('large').value;
    }
    else {
        allDataEntered=false;
        alert("Please select the size of ice cream");
    }
   
    var quantity=document.getElementById("quantity").value;
    
    if(quantity===""){
        allDataEntered=false;
        alert("Please enter a Quantity between 1-10");
    }
    else if(quantity>10){
        allDataEntered=false;
        alert("Please enter a Quantity below 10");
    }
    else if(quantity<=0){
         allDataEntered=false;
        alert("Please enter a Quantity atleast 1");
    }
    
    if(document.getElementById("toppings1").checked){
     toppings1=document.getElementById("toppings1").value;
    }   
    if(document.getElementById("toppings2").checked){
     toppings2=document.getElementById("toppings2").value;
    }
    
    if(allDataEntered==true){
    request = new XMLHttpRequest();
    var url = "Ambati?flavor="+flavor+"&size="+size+"&quantity="+quantity+"&toppings1="+toppings1+"&toppings2="+toppings2;
    
   //url is the url for servlet
    request.open("GET",url, true);
    
    request.onreadystatechange = displayResult; // Call back fn is displayCoursers
   
    request.send(null);
    }
}

function displayResult() {
   if (request.readyState === 4 && request.status === 200) {
      document.getElementById("message").innerHTML = request.responseText;
   }
}