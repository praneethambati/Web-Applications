/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import static java.lang.Integer.parseInt;
import java.text.DecimalFormat;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author S524965
 */
@WebServlet(urlPatterns = {"/Ambati"})
        public class Ambati extends HttpServlet {
        public static final double SMALL = 6.00;
        public static final double MEDIUM = 9.00;
        public static final double LARGE = 11.00;
        public static final double CHOCOLATE = 1.00;
        public static final double MINTCHOCOLATE = 1.25;
        public static final double STRAWBERRY = 1.50;
        public static final double VANILLA = 1.50;
        public static final double SALTED=0.50;
        public static final double SUGARFREE=0.70;
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
     
       
        
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            
        
        
        double price = 0.00;
        boolean allDataEntered = true;
        String quantity;
        String flavor=request.getParameter("flavor");
        String size=request.getParameter("size");
        String toppings1= request.getParameter("toppings1");
        String toppings2= request.getParameter("toppings2");
        DecimalFormat df=new DecimalFormat("#0.00");
  
   
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Confirmation Page</title>");  
            out.println("<link type=\"text/css\" rel=\"stylesheet\" href=\"AmbatiServletCss.css\"/>");  
            out.println("</head>");
            out.println("<body>");
            out.println("<h1> Bearcat Ice Cream Order Confirmation</h1>");
           
            if (request.getParameter("flavor").equals("Chocolate")) {
             price += CHOCOLATE;
      
            } 
            
            else if ("Mint Chocolate Chip".equals(flavor)) {
              price += MINTCHOCOLATE;
            }
            else if ("Strawberry".equals(flavor)) {
               price += STRAWBERRY;
             } 
            else if ("Vanilla".equals(flavor)) {
             price += VANILLA;
             }
            else {
                allDataEntered = false;
                 out.println("<h3>Flavor not selected.</h3>");
                 
            }

             if("small".equals(size)) {
                price += SMALL;
            } else if ("medium".equals(size)) {
              price += MEDIUM;
            } else if ("large".equals(size)) {
             price += LARGE;
            } else {
             allDataEntered = false;
            out.println("<h3>Size not selected.</h3>");
            }
     
          if("salt".equals(toppings1)){
              price+=SALTED;
               
          }
          
          if("sugar".equals(toppings2)){
              price+=SUGARFREE;
            
          }
          
          quantity=request.getParameter("quantity");
          if(quantity==""){
              out.println("<h3>Quantity not entered.</h3>");   
          }
          else if(parseInt(quantity)>=1&&parseInt(quantity)<=10){
             price *=parseInt(quantity);
 
           if(allDataEntered==true) {
               
             
            out.println("<h4>The total cost of your order is $" + df.format(price)+"</h4>");
            if(parseInt(quantity)==1){
            out.println("<h4>Your "+request.getParameter("flavor") +" ice cream will be delivered in about "+(Math.round(Math.random() * (45 - 25)) + 25)+" minutes.</h4>");
            } 
            else{
              out.println("<h4>Your "+request.getParameter("flavor") +" ice creams will be delivered in about "+(Math.round(Math.random() * (45 - 25)) + 25)+" minutes.</h4>");
              
            }
            }
            }
        else{
              out.println("<h3>Quantity not entered.</h3>");   
          }
         
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
