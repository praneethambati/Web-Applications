/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


$(document).ready(
        function() {
            $("#findBtn").click(getInfo);
            
        }
);


function getInfo() {
    $("#listItems").empty();
    var url="Ambati?distance="+$("#distance").val()+"&diameter="+$("#diameter").val()+"&gravity="+$("#gravity").val();
    $.getJSON(url, displayInfo);
   
}

function displayInfo(data) {
    $("#listItems").empty();
    $.each(data.menu,
            function() {
                $("#listItems").append(
                        "<tr>"
                        + "<td>" + this.name + "</td>"
                        + "<td>" + this.distance + "</td>"
                        + "<td>" + this.period + "</td>"
                        + "<td>" + this.diameter + "</td>"
                        + "<td>" + this.mass + "</td>"
                        + "<td>" + this.gravity + "</td>"
                        + "</tr>");
            });
}