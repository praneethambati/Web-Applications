/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import static java.lang.Integer.parseInt;

import java.text.DecimalFormat;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author S524965
 */
@WebServlet(urlPatterns = {"/Ambati"})
public class Ambati extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            double length = 0;
            double  perimeter = 0;
             double area = 0;
            int sides=parseInt(request.getParameter("sides"));
            int radius= parseInt(request.getParameter("radius"));
            
           if(sides>2)
           {
         
           
           length=2*radius*Math.sin(Math.PI/sides);
           perimeter=length*sides;
           area=((radius*radius*sides*(Math.sin(2*Math.PI/sides)))/2);
           DecimalFormat numberFormat1 = new DecimalFormat("#0.00");
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet Ambati</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<p>A rectangular polygon with number of sides " +sides+ " and radius " + numberFormat1.format(radius)+" has the following measurements:</p>");
            out.println("<p>Side length = "+numberFormat1.format(length)+"</p>");
            out.println("<p>Perimeter = "+numberFormat1.format(perimeter)+"</p>");
            out.println("<p>Area = "+numberFormat1.format(area)+"</p>");
            out.println("</body>");
            out.println("</html>");
  
       }
       else
       {
           //window.alert("Minimum sides value should be above 2");
           out.println("<h3>Please enter the length above 2 & radius above 1</h3>");
       }
         
            
           
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
