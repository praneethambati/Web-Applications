/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nerdneighborhood;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.inject.Named;

/**
 *
 * @author s524965
 */
@ManagedBean
@Named(value = "ambati")
@RequestScoped
public class Ambati {

    String name;
    Double Latitude;
    Double Longitude;
    String LOC;
    String NStartUps;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Double getLatitude() {
        return Latitude;
    }

    public void setLatitude(Double Latitude) {
        this.Latitude = Latitude;
    }

    public Double getLongitude() {
        return Longitude;
    }

    public void setLongitude(Double Longitude) {
        this.Longitude = Longitude;
    }

    public String getLOC() {
        return LOC;
    }

    public void setLOC(String LOC) {
        this.LOC = LOC;
    }

    public String getNStartUps() {
        return NStartUps;
    }

    public void setNStartUps(String NStartUps) {
        this.NStartUps = NStartUps;
    }
    
    
    /**
     * Creates a new instance of Ambati
     */
    public Ambati() {
    }
    
    public String response(){
        int intLOC=Integer.valueOf(LOC, 16);
        int intNStartUps=Integer.valueOf(NStartUps, 2);
        
        int nerdScore= (intLOC / 1000) + intNStartUps;
        
        
        return (nerdScore >= 5) ? "Accept" : "Reject";
    }
    
    
}
